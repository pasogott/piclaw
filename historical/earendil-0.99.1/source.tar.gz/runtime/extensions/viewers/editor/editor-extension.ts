import { editorTheme } from "./theme.js";
import { themeClassHighlighter } from "./syntax-highlighter.js";
/**
 * editor-extension.ts — Standalone editor pane extension.
 *
 * Creates and manages a CodeMirror 6 editor directly — no Preact wrapper.
 * Owns its own DOM lifecycle (mount/dispose), dirty tracking, file I/O,
 * vim/whitespace toggles, theming, and status bar.
 *
 * Communicates with the host exclusively via the PaneInstance contract:
 *   Host → Extension: setContent(), focus(), resize()
 *   Extension → Host: onDirtyChange(), onSaveRequest(), onClose()
 */

import {
    EditorState,
    EditorView,
    Compartment,
    minimalSetup,
    lineNumbers,
    highlightActiveLine,
    highlightWhitespace,
    scrollPastEnd,
    showPanel,
    javascript,
    python,
    markdown,
    markdownLanguage,
    go,
    cpp,
    json,
    css,
    html as htmlLang,
    rust,
    yaml,
    sql,
    xml,
    StreamLanguage,
    HighlightStyle,
    syntaxHighlighting,
    indentOnInput,
    indentUnit,
    tags,
    shell,
    keymap,
    indentWithTab,
    search,
    searchKeymap,
    autocompletion,
    completionKeymap,
    closeBrackets,
    closeBracketsKeymap,
    vim,
    MergeView,
} from '#editor-vendor/codemirror';
import { getWorkspaceBranch, getWorkspaceFile, updateWorkspaceFile, uploadWorkspaceFile } from '../../../web/src/api.js';
import { createFileConflictMonitor, type FileConflictMonitor } from '../../../web/src/panes/file-conflict-monitor.js';
import type { WebPaneExtension, PaneContext, PaneInstance, PaneCapability, PaneHostAttachContext, PaneHostDetachContext } from '../../../web/src/panes/pane-types.js';
import { frontmatterExtension } from './markdown/frontmatter.js';
import { footnoteExtension } from './markdown/footnote.js';
import { hashtagExtension } from './markdown/tag.js';
import {
    getLocalBoolWithFallback,
    restoreEditorViewStateBestEffort,
    setLocalBoolBestEffort,
    shouldDisableWhitespaceMarkersForPerformance,
} from './editor-safety.ts';
import {
    closeEditorSearch,
    isEditorSearchOpen,
    openEditorSearch,
    revealText as revealEditorText,
    searchRevealExtension,
} from './search-reveal.js';
import {
    buildMarkdownImageText,
    buildPastedImageFilename,
    getPastedImageExtension,
    getPastedImageFiles,
    getWorkspaceDirectoryForEditorPath,
} from './paste-image.js';
import {
    dispatchEditorFileReferenceRequest,
    normalizeEditorFileReferencePath,
} from '../../../web/src/ui/editor-file-reference.js';

// ── Constants ───────────────────────────────────────────────────

const MONO_STACK = 'ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace';
const EDITOR_MAX_BYTES = 256 * 1024;
const LARGE_DOCUMENT_CHARS = 48 * 1024;
const LARGE_DOCUMENT_LINES = 1_000;
const LARGE_DOCUMENT_LINE_CHARS = 2_000;
const DIRTY_RECHECK_DELAY_MS = 500;
const CONTENT_CHANGE_DEBOUNCE_MS = 1000;

const shellLanguage = StreamLanguage.define(shell);

const headingStyle = HighlightStyle.define([
    { tag: tags.heading1, fontWeight: 'bold', fontSize: '1.3em', textDecoration: 'none' },
    { tag: tags.heading2, fontWeight: 'bold', fontSize: '1.2em', textDecoration: 'none' },
    { tag: tags.heading3, fontWeight: 'bold', fontSize: '1.1em', textDecoration: 'none' },
    { tag: tags.heading4, fontWeight: 'bold', textDecoration: 'none' },
    { tag: tags.heading5, fontWeight: 'bold', textDecoration: 'none' },
    { tag: tags.heading6, fontWeight: 'bold', textDecoration: 'none' },
]);

// ── Helpers ─────────────────────────────────────────────────────

function getThemeMode(doc: Document): 'dark' | 'light' {
    return doc.documentElement.dataset.theme === 'light' ? 'light' : 'dark';
}

function getLocalBool(key: string, fallback: boolean): boolean {
    return getLocalBoolWithFallback(() => localStorage, key, fallback);
}

function setLocalBool(key: string, value: boolean): void {
    setLocalBoolBestEffort(() => localStorage, key, value);
}

function getDocumentSizeProfile(text: string): { lines: number; maxLineChars: number } {
    let lines = 1;
    let currentLineChars = 0;
    let maxLineChars = 0;
    for (let i = 0; i < text.length; i++) {
        if (text.charCodeAt(i) === 10) {
            lines += 1;
            if (currentLineChars > maxLineChars) maxLineChars = currentLineChars;
            currentLineChars = 0;
        } else {
            currentLineChars += 1;
        }
        if (lines > LARGE_DOCUMENT_LINES || currentLineChars > LARGE_DOCUMENT_LINE_CHARS) {
            return { lines, maxLineChars: Math.max(maxLineChars, currentLineChars) };
        }
    }
    return { lines, maxLineChars: Math.max(maxLineChars, currentLineChars) };
}

function isLargeDocumentContent(content: string): boolean {
    const profile = getDocumentSizeProfile(content);
    return content.length > LARGE_DOCUMENT_CHARS || profile.lines > LARGE_DOCUMENT_LINES || profile.maxLineChars > LARGE_DOCUMENT_LINE_CHARS;
}

/** Map file extension → CodeMirror language extension. */
interface EditorHostTransferState {
    kind?: string;
    path?: string;
    content?: string;
    initialContent?: string;
    mtime?: string | null;
    dirty?: boolean;
    diffMode?: 'saved' | null;
    viewState?: {
        cursorLine?: number;
        cursorCol?: number;
        scrollTop?: number;
    } | null;
}

function normalizeEditorHostTransferState(value: unknown): EditorHostTransferState | null {
    if (!value || typeof value !== 'object' || Array.isArray(value)) return null;
    const raw = value as Record<string, unknown>;
    const kind = typeof raw.kind === 'string' ? raw.kind.trim() : '';
    if (kind && kind !== 'editor') return null;
    return {
        kind: kind || 'editor',
        path: typeof raw.path === 'string' ? raw.path : undefined,
        content: typeof raw.content === 'string' ? raw.content : undefined,
        initialContent: typeof raw.initialContent === 'string' ? raw.initialContent : undefined,
        mtime: typeof raw.mtime === 'string' ? raw.mtime : (raw.mtime === null ? null : undefined),
        dirty: typeof raw.dirty === 'boolean' ? raw.dirty : undefined,
        diffMode: raw.diffMode === 'saved' ? 'saved' : null,
        viewState: raw.viewState && typeof raw.viewState === 'object'
            ? {
                cursorLine: typeof (raw.viewState as any).cursorLine === 'number' ? (raw.viewState as any).cursorLine : undefined,
                cursorCol: typeof (raw.viewState as any).cursorCol === 'number' ? (raw.viewState as any).cursorCol : undefined,
                scrollTop: typeof (raw.viewState as any).scrollTop === 'number' ? (raw.viewState as any).scrollTop : undefined,
            }
            : null,
    };
}

function languageForPath(path: string) {
    const lower = String(path || '').toLowerCase();
    if (lower.endsWith('.py')) return python();
    if (lower.endsWith('.rs')) return rust();
    if (lower.endsWith('.ts') || lower.endsWith('.tsx')) return javascript({ typescript: true, jsx: lower.endsWith('.tsx') });
    if (lower.endsWith('.js') || lower.endsWith('.jsx')) return javascript({ jsx: lower.endsWith('.jsx') });
    if (lower.endsWith('.md') || lower.endsWith('.markdown')) return markdown({
        base: markdownLanguage,
        extensions: [frontmatterExtension, footnoteExtension, hashtagExtension],
    });
    if (lower.endsWith('.go')) return go();
    if (lower.endsWith('.c++') || lower.endsWith('.cc') || lower.endsWith('.cp') || lower.endsWith('.cpp') || lower.endsWith('.cxx')
        || lower.endsWith('.hh') || lower.endsWith('.hpp') || lower.endsWith('.hxx')) return cpp();
    if (lower.endsWith('.json') || lower.endsWith('.jsonl')) return json();
    if (lower.endsWith('.css') || lower.endsWith('.scss')) return css();
    if (lower.endsWith('.html') || lower.endsWith('.htm')) return htmlLang();
    if (lower.endsWith('.yaml') || lower.endsWith('.yml')) return yaml();
    if (lower.endsWith('.sql') || lower.endsWith('.sqlite')) return sql();
    if (lower.endsWith('.xml') || lower.endsWith('.svg') || lower.endsWith('.plist')) return xml();
    if (lower.endsWith('.sh') || lower.endsWith('.bash') || lower.endsWith('.zsh') || lower.endsWith('.env')) return shellLanguage;
    return null;
}

// ── Status bar panel ────────────────────────────────────────────

function createStatusPanel(doc: Document, vimEnabledRef: { current: boolean }) {
    return (view: EditorView) => {
        const dom = doc.createElement('div');
        dom.className = 'cm-statusbar';

        const left = doc.createElement('div');
        left.className = 'cm-statusbar-left';

        const right = doc.createElement('div');
        right.className = 'cm-statusbar-right';

        dom.append(left, right);

        let rafPending = false;
        let lastLeftText = '';
        let lastRightText = '';

        const flush = () => {
            rafPending = false;
            const state = view.state;
            const pos = state.selection.main.head;
            const line = state.doc.lineAt(pos);
            const col = pos - line.from + 1;
            const unit = state.facet(indentUnit) || '  ';
            const indentLabel = unit === '\t' ? 'Tabs' : `Spaces:${unit.length}`;
            const vimLabel = vimEnabledRef.current ? 'Vim' : 'Insert';
            const nextLeft = `Ln ${line.number}, Col ${col}`;
            const nextRight = `${indentLabel} • ${vimLabel}`;
            if (nextLeft !== lastLeftText) { left.textContent = nextLeft; lastLeftText = nextLeft; }
            if (nextRight !== lastRightText) { right.textContent = nextRight; lastRightText = nextRight; }
        };

        flush();

        return {
            dom,
            update: (updateEvent: any) => {
                if (!rafPending && (updateEvent.docChanged || updateEvent.selectionSet)) {
                    rafPending = true;
                    requestAnimationFrame(flush);
                }
            },
            destroy: () => {},
        };
    };
}

// ── EditorPaneInstance ──────────────────────────────────────────

/**
 * Self-contained editor pane instance. Creates CodeMirror directly,
 * manages file I/O, dirty tracking, and theming internally.
 */
export class StandaloneEditorInstance implements PaneInstance {
    // DOM
    private container: HTMLElement;
    private ownerDocument: Document;
    private ownerWindow: Window & typeof globalThis;
    private paneEl: HTMLElement;
    private headerEl: HTMLElement | null = null;
    private bodyEl: HTMLElement;
    private cmHost: HTMLElement;
    private diffShellEl: HTMLElement;
    private diffMergeHost: HTMLElement;
    private statusEl: HTMLElement;

    // CodeMirror
    private view: EditorView | null = null;
    private baselineView: EditorView | null = null;
    private mergeView: MergeView | null = null;
    private vimCompartment = new Compartment();
    private themeCompartment = new Compartment();
    private whitespaceCompartment = new Compartment();
    private livePreviewCompartment = new Compartment();
    private wrappingCompartment = new Compartment();
    private languageCompartment = new Compartment();
    private baselineThemeCompartment = new Compartment();
    private baselineWhitespaceCompartment = new Compartment();

    // State
    private path: string;
    private initialContent = '';
    private currentMtime: string | null = null;
    private dirty = false;
    private saving = false;
    private disposed = false;
    private vimEnabled: boolean;
    private showWhitespace: boolean;
    private livePreviewEnabled: boolean;
    private largeDocumentMode = false;
    private initialContentLength = 0;
    private dirtyRecheckTimer: number | null = null;
    private _viewStateRafPending = false;
    private contentChangeTimer: number | null = null;
    private diffMode: 'saved' | null = null;
    private vimEnabledRef: { current: boolean };

    // Callbacks (PaneInstance contract)
    private dirtyChangeCb: ((dirty: boolean) => void) | null = null;
    private saveRequestCb: ((content: string) => void) | null = null;
    private closeCb: (() => void) | null = null;
    private viewStateChangeCb: ((state: { cursorLine: number; cursorCol: number; scrollTop: number; content?: string }) => void) | null = null;
    private contentChangeCb: ((content: string) => void) | null = null;

    // External change detection
    private conflictMonitor: FileConflictMonitor | null = null;

    constructor(container: HTMLElement, context: PaneContext) {
        this.container = container;
        this.ownerDocument = container.ownerDocument || document;
        this.ownerWindow = (this.ownerDocument.defaultView || window) as Window & typeof globalThis;
        this.path = context.path || '';

        this.vimEnabled = getLocalBool('piclaw_vim_mode', false);
        this.showWhitespace = getLocalBool('piclaw_show_whitespace', true);
        this.livePreviewEnabled = getLocalBool('piclaw_md_live_preview', true);
        this.vimEnabledRef = { current: this.vimEnabled };

        this.handleThemeChange = this.handleThemeChange.bind(this);
        this.handleGlobalKeydown = this.handleGlobalKeydown.bind(this);

        this.initializeHostDom(container);
        this.bindHostListeners();
        this.bootstrapInitialContext(context);
    }

    // ── DOM builders ────────────────────────────────────────────

    private initializeHostDom(container: HTMLElement): void {
        this.container = container;
        this.ownerDocument = container.ownerDocument || this.ownerDocument || document;
        this.ownerWindow = (this.ownerDocument.defaultView || this.ownerWindow || window) as Window & typeof globalThis;

        container.innerHTML = '';
        this.paneEl = this.ownerDocument.createElement('div');
        this.paneEl.className = 'editor-pane';

        this.bodyEl = this.ownerDocument.createElement('div');
        this.bodyEl.className = 'editor-body';

        this.cmHost = this.ownerDocument.createElement('div');
        this.cmHost.className = 'editor-codemirror';

        this.diffShellEl = this.ownerDocument.createElement('div');
        this.diffShellEl.className = 'editor-diff-shell';
        this.diffShellEl.hidden = true;

        const diffHeaders = this.ownerDocument.createElement('div');
        diffHeaders.className = 'editor-diff-headers';
        diffHeaders.innerHTML = `
            <div class="editor-diff-header editor-diff-header-saved">Saved</div>
            <div class="editor-diff-header editor-diff-header-current">Current</div>
        `;

        this.diffMergeHost = this.ownerDocument.createElement('div');
        this.diffMergeHost.className = 'editor-diff-merge';

        this.diffShellEl.appendChild(diffHeaders);
        this.diffShellEl.appendChild(this.diffMergeHost);

        this.bodyEl.appendChild(this.cmHost);
        this.bodyEl.appendChild(this.diffShellEl);

        this.statusEl = this.buildStatusBar();

        this.paneEl.appendChild(this.bodyEl);
        this.paneEl.appendChild(this.statusEl);
        container.appendChild(this.paneEl);
    }

    private bindHostListeners(): void {
        this.ownerWindow.addEventListener('piclaw-theme-change', this.handleThemeChange as EventListener);
        this.ownerDocument.addEventListener('keydown', this.handleGlobalKeydown as EventListener);
    }

    private unbindHostListeners(): void {
        this.ownerWindow.removeEventListener('piclaw-theme-change', this.handleThemeChange as EventListener);
        this.ownerDocument.removeEventListener('keydown', this.handleGlobalKeydown as EventListener);
    }

    private bootstrapInitialContext(context: PaneContext): void {
        const transferState = normalizeEditorHostTransferState(context.transferState);
        if (transferState?.diffMode === 'saved') {
            this.diffMode = 'saved';
        }

        if (context.content !== undefined) {
            this.mountEditor(context.content, context.mtime);
            if (context.dirty) {
                this.setDirty(true);
            }
            if (transferState) {
                this.applyHostTransferState(transferState);
            }
        } else if (transferState?.content !== undefined) {
            this.mountEditor(transferState.content, transferState.mtime);
            this.applyHostTransferState(transferState);
        } else {
            void this.loadFile();
        }

        void this.refreshBranchHint();
    }

    private buildStatusBar(): HTMLElement {
        const row = this.ownerDocument.createElement('div');
        row.className = 'editor-status editor-status-row';

        const meta = this.ownerDocument.createElement('div');
        meta.className = 'editor-status-meta';

        const branch = this.ownerDocument.createElement('span');
        branch.className = 'editor-branch-hint';
        branch.hidden = true;
        branch.innerHTML = `
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                <path d="M6 3v12"></path>
                <circle cx="18" cy="6" r="3"></circle>
                <circle cx="6" cy="18" r="3"></circle>
                <path d="M18 9a9 9 0 0 1-9 9"></path>
            </svg>
            <span class="editor-branch-label"></span>
        `;
        this._branchHint = branch;
        this._branchLabel = branch.querySelector('.editor-branch-label');

        const text = this.ownerDocument.createElement('span');
        text.className = 'editor-status-text';
        text.textContent = 'Ready';
        this._statusText = text;

        meta.appendChild(branch);
        meta.appendChild(text);

        const actionsDiv = this.ownerDocument.createElement('div');
        actionsDiv.className = 'editor-status-actions';

        const wsBtn = this.ownerDocument.createElement('button');
        wsBtn.className = `editor-status-button${this.showWhitespace ? ' active' : ''}`;
        wsBtn.title = 'Toggle whitespace (Alt+W)';
        wsBtn.textContent = 'Whitespace';
        wsBtn.addEventListener('click', () => this.toggleWhitespace());
        this._wsBtn = wsBtn;

        const lpBtn = this.ownerDocument.createElement('button');
        lpBtn.className = `editor-status-button${this.livePreviewEnabled ? ' active' : ''}`;
        lpBtn.title = 'Toggle live preview (Alt+P)';
        lpBtn.textContent = 'Live Preview';
        lpBtn.addEventListener('click', () => this.toggleLivePreview());
        this._lpBtn = lpBtn;

        const vimBtn = this.ownerDocument.createElement('button');
        vimBtn.className = `editor-status-button${this.vimEnabled ? ' active' : ''}`;
        vimBtn.title = 'Toggle Vim mode (Alt+V)';
        vimBtn.textContent = 'Vim';
        vimBtn.addEventListener('click', () => this.toggleVim());
        this._vimBtn = vimBtn;

        const saveBtn = this.ownerDocument.createElement('button');
        saveBtn.className = 'editor-status-button editor-save-btn';
        saveBtn.title = 'Save (Ctrl+S)';
        saveBtn.textContent = 'Save';
        saveBtn.addEventListener('click', () => this.handleSave());
        this._saveBtn = saveBtn;

        const referenceBtn = this.ownerDocument.createElement('button');
        referenceBtn.className = 'editor-status-button editor-reference-btn';
        referenceBtn.textContent = 'Reference';
        referenceBtn.addEventListener('click', () => this.handleReferenceFile());
        this._referenceBtn = referenceBtn;

        actionsDiv.appendChild(wsBtn);
        actionsDiv.appendChild(lpBtn);
        actionsDiv.appendChild(vimBtn);
        actionsDiv.appendChild(saveBtn);
        actionsDiv.appendChild(referenceBtn);
        row.appendChild(meta);
        row.appendChild(actionsDiv);

        this.updateLivePreviewControlState();
        this.updateWhitespaceControlState();
        this.updateReferenceButton();
        return row;
    }
    private _branchHint: HTMLElement | null = null;
    private _branchLabel: HTMLElement | null = null;
    private _statusText: HTMLElement | null = null;
    private _wsBtn: HTMLButtonElement | null = null;
    private _lpBtn: HTMLButtonElement | null = null;
    private _vimBtn: HTMLButtonElement | null = null;
    private _saveBtn: HTMLButtonElement | null = null;
    private _referenceBtn: HTMLButtonElement | null = null;
    private branchRequestToken = 0;

    // ── File I/O ────────────────────────────────────────────────

    /** Load file content from the workspace API. */
    private async loadFile(): Promise<void> {
        this.setLoadingUI(true);
        try {
            const data = await getWorkspaceFile(this.path, EDITOR_MAX_BYTES, 'edit');
            if (this.disposed) return;

            if (data?.error) {
                this.setErrorUI(data.error);
                return;
            }
            if (data?.kind && data.kind !== 'text') {
                this.setErrorUI('File is not editable');
                return;
            }

            this.mountEditor(data?.text || '', data?.mtime || null);
        } catch (err: any) {
            if (!this.disposed) {
                this.setErrorUI(err.message || 'Failed to load file');
            }
        }
    }

    /** Save current content to disk via workspace API. */
    private async handleSave(): Promise<void> {
        if (this.saving || !this.view || !this.dirty) return;

        const value = this.view.state.doc.toString();
        if (value === this.initialContent) {
            this.clearDirtyRecheckTimer();
            this.setDirty(false);
            this.updateStatusText('All changes saved');
            return;
        }
        this.saving = true;
        this.updateSaveButton();
        this.updateStatusText('Saving…');

        // Notify host about save attempt (content for the tab store)
        this.saveRequestCb?.(value);

        try {
            const result = await updateWorkspaceFile(this.path, value);
            if (this.disposed) return;

            this.initialContent = value;
            this.initialContentLength = value.length;
            this.largeDocumentMode = isLargeDocumentContent(value);
            this.currentMtime = result?.mtime || this.currentMtime;
            this.conflictMonitor?.onSaved(this.currentMtime);
            if (this.isDiffMode()) {
                const viewState = this.captureViewState();
                this.renderEditorSurface(value, 'saved', viewState);
            }
            this.setDirty(false);
            this.saving = false;
            this.updateSaveButton();
            this.updateStatusText('All changes saved');
        } catch (err: any) {
            if (this.disposed) return;
            this.saving = false;
            this.updateSaveButton();
            this.updateStatusText(`Save failed: ${err.message || 'Unknown error'}`);
        }
    }

    // ── CodeMirror lifecycle ────────────────────────────────────

    /** Create the CodeMirror editor with content. */
    private mountEditor(content: string, mtime?: string | null): void {
        this.initialContent = content;
        this.initialContentLength = content.length;
        this.largeDocumentMode = isLargeDocumentContent(content);
        this.currentMtime = mtime || null;
        this.setLoadingUI(false);
        this.renderEditorSurface(content, this.diffMode === 'saved' ? 'saved' : null, null);
        this.setDirty(false);
        this.updateLivePreviewControlState();
        this.updateWhitespaceControlState();
        this.updateGutterWidth();
        this.initConflictMonitor();
        if (this.largeDocumentMode) {
            this.updateStatusText('Large file mode: live preview, whitespace markers, wrapping, and syntax parsing disabled');
        }
    }

    private renderEditorSurface(content: string, diffMode: 'saved' | null, viewState: { cursorLine?: number; cursorCol?: number; scrollTop?: number } | null): void {
        this.destroyEditorViews();
        if (diffMode === 'saved') {
            this.renderFreshDiffEditor(content, this.initialContent, viewState);
            return;
        }
        this.renderFreshEditor(content, viewState);
    }

    private destroyEditorViews(): void {
        if (this.mergeView) {
            this.mergeView.destroy();
            this.mergeView = null;
            this.baselineView = null;
            this.view = null;
        } else if (this.view) {
            this.view.destroy();
            this.view = null;
        }
        this.baselineView = null;
        this.cmHost.innerHTML = '';
        this.diffMergeHost.innerHTML = '';
    }

    private setEditorSurfaceMode(diffMode: 'saved' | null): void {
        const enabled = diffMode === 'saved';
        this.cmHost.hidden = enabled;
        this.diffShellEl.hidden = !enabled;
        this.bodyEl.classList.toggle('editor-body-diff', enabled);
    }

    private buildSharedEditorTheme(): ReturnType<typeof EditorView.theme> {
        return EditorView.theme({
            '&': { height: '100%', fontFamily: MONO_STACK },
            '.cm-scroller': { fontFamily: MONO_STACK },
            '.cm-content': { fontFamily: MONO_STACK, fontSize: '12px' },
            '.cm-gutters': { fontFamily: MONO_STACK },
        });
    }

    private buildEditableEditorExtensions(options: { scrollPastEnd?: boolean } = {}): any[] {
        const isDark = getThemeMode(this.ownerDocument) === 'dark';
        const enableRichFeatures = !this.largeDocumentMode;
        const lang = enableRichFeatures ? languageForPath(this.path) : null;
        const extensions: any[] = [
            minimalSetup,
            lineNumbers(),
            highlightActiveLine(),
            this.whitespaceCompartment.of(enableRichFeatures && this.shouldApplyWhitespaceMarkers() ? highlightWhitespace() : []),
            this.livePreviewCompartment.of([]),
            this.wrappingCompartment.of(enableRichFeatures ? EditorView.lineWrapping : []),
            this.languageCompartment.of(lang || []),
            ...(options.scrollPastEnd === false ? [] : [scrollPastEnd()]),
            ...(enableRichFeatures ? [indentOnInput()] : []),
            ...(this.isMarkdownFile() ? [] : [closeBrackets()]),
            ...(enableRichFeatures ? [autocompletion({ activateOnTyping: false })] : []),
            ...(enableRichFeatures ? [syntaxHighlighting(headingStyle), syntaxHighlighting(themeClassHighlighter)] : []),
            search(),
            searchRevealExtension,
            this.vimCompartment.of([]), // vim loaded async after mount
            this.themeCompartment.of(editorTheme(isDark)),
            showPanel.of(createStatusPanel(this.ownerDocument, this.vimEnabledRef)),
            keymap.of([
                ...searchKeymap,
                ...completionKeymap,
                ...closeBracketsKeymap,
                indentWithTab,
                { key: 'Mod-s', run: () => { this.handleSave(); return true; } },
            ]),
            ...(this.isMarkdownFile() ? [EditorView.domEventHandlers({
                paste: (event: ClipboardEvent) => this.handlePaste(event),
            })] : []),
            EditorView.updateListener.of((update: any) => {
                if (update.docChanged) {
                    this.checkDirty();
                    this.scheduleContentChangeCallback();
                }
                if ((update.selectionSet || update.docChanged) && this.viewStateChangeCb) {
                    if (!this._viewStateRafPending) {
                        this._viewStateRafPending = true;
                        requestAnimationFrame(() => {
                            this._viewStateRafPending = false;
                            if (!this.view || !this.viewStateChangeCb) return;
                            const pos = this.view.state.selection.main.head;
                            const line = this.view.state.doc.lineAt(pos);
                            const col = pos - line.from + 1;
                            const scrollTop = this.view.scrollDOM?.scrollTop || 0;
                            this.viewStateChangeCb({ cursorLine: line.number, cursorCol: col, scrollTop });
                        });
                    }
                }
            }),
            this.buildSharedEditorTheme(),
        ];
        return extensions;
    }

    private buildBaselineEditorExtensions(): any[] {
        const isDark = getThemeMode(this.ownerDocument) === 'dark';
        const enableRichFeatures = !this.largeDocumentMode;
        const lang = enableRichFeatures ? languageForPath(this.path) : null;
        const extensions: any[] = [
            minimalSetup,
            lineNumbers(),
            this.baselineWhitespaceCompartment.of(enableRichFeatures && this.shouldApplyWhitespaceMarkers() ? highlightWhitespace() : []),
            this.baselineThemeCompartment.of(editorTheme(isDark)),
            ...(enableRichFeatures ? [EditorView.lineWrapping, syntaxHighlighting(headingStyle), syntaxHighlighting(themeClassHighlighter)] : []),
            EditorState.readOnly.of(true),
            EditorView.editable.of(false),
            this.buildSharedEditorTheme(),
        ];
        if (lang) extensions.push(lang);
        return extensions;
    }

    private renderFreshEditor(content: string, viewState: { cursorLine?: number; cursorCol?: number; scrollTop?: number } | null): void {
        this.setEditorSurfaceMode(null);
        const state = EditorState.create({
            doc: content,
            extensions: this.buildEditableEditorExtensions({ scrollPastEnd: true }),
        });
        this.view = new EditorView({ state, parent: this.cmHost });
        if (viewState) requestAnimationFrame(() => this.restoreViewState(viewState));
        if (this.isLivePreviewAvailable() && this.livePreviewEnabled) {
            void this.applyLivePreview(true);
        }
        if (this.vimEnabled) {
            void this.applyVimMode(true);
        }
    }

    private renderFreshDiffEditor(currentContent: string, baselineContent: string, viewState: { cursorLine?: number; cursorCol?: number; scrollTop?: number } | null): void {
        this.setEditorSurfaceMode('saved');
        this.mergeView = new MergeView({
            a: {
                doc: baselineContent,
                extensions: this.buildBaselineEditorExtensions(),
            },
            b: {
                doc: currentContent,
                extensions: this.buildEditableEditorExtensions({ scrollPastEnd: false }),
            },
            parent: this.diffMergeHost,
            root: this.ownerDocument,
            revertControls: false,
            highlightChanges: true,
            gutter: true,
            diffConfig: {
                scanLimit: 5000,
                timeout: 80,
            },
        });
        this.baselineView = this.mergeView.a;
        this.view = this.mergeView.b;
        if (viewState) requestAnimationFrame(() => this.restoreViewState(viewState));
    }

    /** Check if current file is Markdown. */
    private isMarkdownFile(): boolean {
        const lower = (this.path || '').toLowerCase();
        return lower.endsWith('.md') || lower.endsWith('.markdown');
    }

    private isDiffMode(): boolean {
        return this.diffMode === 'saved';
    }

    /** Some markdown-backed formats should open as raw source, not live preview. */
    private supportsMarkdownLivePreview(): boolean {
        const lower = (this.path || '').toLowerCase();
        if (lower.endsWith('.kanban.md')) return false;
        return this.isMarkdownFile();
    }

    private isLivePreviewAvailable(): boolean {
        return !this.largeDocumentMode && !this.isDiffMode() && this.supportsMarkdownLivePreview();
    }

    /** Lazy-load and apply/remove markdown live preview extensions. */
    private async applyLivePreview(enabled: boolean): Promise<void> {
        if (!this.view || this.disposed || this.isDiffMode()) return;
        const wrapEffect = this.wrappingCompartment.reconfigure(this.largeDocumentMode ? [] : EditorView.lineWrapping);

        if (enabled) {
            const targetView = this.view;
            try {
                const { createMarkdownLivePreview } = await import('./markdown/index.js');
                if (
                    this.disposed
                    || !this.view
                    || this.view !== targetView
                    || !this.livePreviewEnabled
                    || !this.isLivePreviewAvailable()
                ) return;
                this.view.dispatch({
                    effects: [
                        this.livePreviewCompartment.reconfigure([createMarkdownLivePreview(this.path), EditorView.editorAttributes.of({ class: 'cm-markdown-preview' })]),
                        this.whitespaceCompartment.reconfigure(this.shouldApplyWhitespaceMarkers() ? highlightWhitespace() : []),
                        wrapEffect,
                    ],
                });
            } catch (err) {
                console.error('[editor] Failed to load markdown live preview:', err);
            }
        } else {
            this.view.dispatch({
                effects: [
                    this.livePreviewCompartment.reconfigure([]),
                    this.whitespaceCompartment.reconfigure(this.shouldApplyWhitespaceMarkers() ? highlightWhitespace() : []),
                    wrapEffect,
                ],
            });
        }
    }

    /**
     * Toggle live preview mode. Called from tab context menu.
     * Only meaningful for Markdown files.
     */
    toggleLivePreview(): void {
        if (!this.isLivePreviewAvailable()) return;
        this.livePreviewEnabled = !this.livePreviewEnabled;
        setLocalBool('piclaw_md_live_preview', this.livePreviewEnabled);
        void this.applyLivePreview(this.livePreviewEnabled);
        this.updateLivePreviewControlState();
        this.updateWhitespaceControlState();
    }

    /** Whether live preview is currently on. */
    isLivePreview(): boolean {
        return this.livePreviewEnabled && this.isLivePreviewAvailable();
    }

    private isWhitespaceDisabledInCurrentMode(): boolean {
        return shouldDisableWhitespaceMarkersForPerformance({
            largeDocumentMode: this.largeDocumentMode,
            livePreviewActive: this.isLivePreview(),
        });
    }

    private shouldApplyWhitespaceMarkers(): boolean {
        return this.showWhitespace && !this.isWhitespaceDisabledInCurrentMode();
    }

    private getWhitespaceDisabledStatusText(): string {
        if (this.largeDocumentMode) return 'Whitespace is disabled in Large File Mode';
        if (this.isLivePreview()) return 'Whitespace is disabled in Live Preview';
        return 'Whitespace is disabled in this editor mode';
    }

    private reconfigureWhitespaceMarkers(): void {
        const extension = this.shouldApplyWhitespaceMarkers() ? highlightWhitespace() : [];
        this.view?.dispatch({ effects: this.whitespaceCompartment.reconfigure(extension) });
        this.baselineView?.dispatch({ effects: this.baselineWhitespaceCompartment.reconfigure(extension) });
    }

    private updateLivePreviewControlState(): void {
        if (!this._lpBtn) return;
        const available = this.isLivePreviewAvailable();
        this._lpBtn.hidden = !available;
        this._lpBtn.disabled = !available;
        this._lpBtn.classList.toggle('active', available && this.livePreviewEnabled);
        this._lpBtn.title = available
            ? 'Toggle live preview (Alt+P)'
            : (this.largeDocumentMode
                ? 'Live Preview is disabled in Large File Mode'
                : (this.isDiffMode() ? 'Live Preview is unavailable in Compare to Saved' : 'Live Preview is unavailable for this file'));
    }

    private updateWhitespaceControlState(): void {
        if (!this._wsBtn) return;
        const disabled = this.isWhitespaceDisabledInCurrentMode();
        this._wsBtn.hidden = false;
        this._wsBtn.disabled = disabled;
        this._wsBtn.classList.toggle('active', !disabled && this.showWhitespace);
        this._wsBtn.title = disabled ? this.getWhitespaceDisabledStatusText() : 'Toggle whitespace (Alt+W)';
    }

    private captureViewState(): { cursorLine: number; cursorCol: number; scrollTop: number } | null {
        if (!this.view) return null;
        try {
            const pos = this.view.state.selection.main.head;
            const line = this.view.state.doc.lineAt(pos);
            const col = pos - line.from + 1;
            const scrollTop = this.view.scrollDOM?.scrollTop || 0;
            return { cursorLine: line.number, cursorCol: col, scrollTop };
        } catch {
            return null;
        }
    }

    private applyHostTransferState(state: EditorHostTransferState): void {
        if (!state) return;
        if (typeof state.path === 'string' && state.path) {
            this.path = state.path;
        }
        if (typeof state.initialContent === 'string') {
            this.initialContent = state.initialContent;
        }
        if (typeof state.mtime === 'string' || state.mtime === null) {
            this.currentMtime = state.mtime || null;
        }
        if ((state.diffMode || null) !== this.diffMode) {
            this.setDiffMode(state.diffMode || null);
        }
        if (this.isDiffMode() && typeof state.initialContent === 'string') {
            const viewState = this.captureViewState();
            this.renderEditorSurface(this.getContent() ?? state.content ?? this.initialContent, this.diffMode, viewState);
        }
        if (state.viewState) {
            requestAnimationFrame(() => this.restoreViewState(state.viewState || null));
        }
        if (typeof state.dirty === 'boolean') {
            this.setDirty(state.dirty);
        }
    }

    /** Compare content to baseline and update dirty state. */
    private checkDirty(fullCompare = false): void {
        if (!this.view) return;
        if (fullCompare) {
            this.clearDirtyRecheckTimer();
            this.setDirty(this.view.state.doc.toString() !== this.initialContent);
            return;
        }
        if (this.view.state.doc.length !== this.initialContentLength) {
            this.clearDirtyRecheckTimer();
            this.setDirty(true);
            return;
        }

        // Same-length edits are dirty immediately. Reconcile after typing has
        // gone idle so an undo back to the saved document clears dirty without
        // serializing CodeMirror's rope in the transaction hot path.
        this.setDirty(true);
        this.scheduleDirtyRecheck();
    }

    private clearDirtyRecheckTimer(): void {
        if (this.dirtyRecheckTimer === null) return;
        this.ownerWindow.clearTimeout(this.dirtyRecheckTimer);
        this.dirtyRecheckTimer = null;
    }

    private scheduleDirtyRecheck(): void {
        this.clearDirtyRecheckTimer();
        this.dirtyRecheckTimer = this.ownerWindow.setTimeout(() => {
            this.dirtyRecheckTimer = null;
            if (!this.view || this.disposed) return;
            this.setDirty(this.view.state.doc.toString() !== this.initialContent);
        }, DIRTY_RECHECK_DELAY_MS);
    }

    private clearContentChangeTimer(): void {
        if (this.contentChangeTimer !== null) {
            this.ownerWindow.clearTimeout(this.contentChangeTimer);
            this.contentChangeTimer = null;
        }
    }

    private scheduleContentChangeCallback(): void {
        if (!this.contentChangeCb || this.largeDocumentMode) return;
        // Skip expensive serialization for documents > 32KB — the preview
        // already disables itself at 96KB but the toString() call alone is costly.
        if (this.view && this.view.state.doc.length > 32_000) return;
        this.clearContentChangeTimer();
        this.contentChangeTimer = this.ownerWindow.setTimeout(() => {
            this.contentChangeTimer = null;
            if (!this.view || this.disposed || !this.contentChangeCb || this.largeDocumentMode) return;
            if (this.view.state.doc.length > 32_000) return;
            this.contentChangeCb(this.view.state.doc.toString());
        }, CONTENT_CHANGE_DEBOUNCE_MS);
    }

    private setDirty(dirty: boolean): void {
        if (this.dirty === dirty) return;
        this.dirty = dirty;
        this.dirtyChangeCb?.(dirty);
        this.updateSaveButton();
        this.updateStatusText(dirty ? 'Unsaved changes' : 'All changes saved');
    }

    // ── Toggle features ─────────────────────────────────────────

    private async applyVimMode(enabled: boolean): Promise<void> {
        if (!this.view || this.disposed) return;
        if (enabled) {
            this.view.dispatch({
                effects: this.vimCompartment.reconfigure(vim()),
            });
        } else {
            this.view.dispatch({
                effects: this.vimCompartment.reconfigure([]),
            });
        }
    }

    private toggleVim(): void {
        this.vimEnabled = !this.vimEnabled;
        this.vimEnabledRef.current = this.vimEnabled;
        setLocalBool('piclaw_vim_mode', this.vimEnabled);
        if (this._vimBtn) this._vimBtn.className = `editor-status-button${this.vimEnabled ? ' active' : ''}`;
        void this.applyVimMode(this.vimEnabled);
    }

    private toggleWhitespace(): void {
        if (this.isWhitespaceDisabledInCurrentMode()) {
            this.updateStatusText(this.getWhitespaceDisabledStatusText());
            return;
        }
        this.showWhitespace = !this.showWhitespace;
        setLocalBool('piclaw_show_whitespace', this.showWhitespace);
        if (this._wsBtn) this._wsBtn.className = `editor-status-button${this.showWhitespace ? ' active' : ''}`;
        this.reconfigureWhitespaceMarkers();
    }

    // ── Paste images ────────────────────────────────────────────

    private handlePaste(event: ClipboardEvent): boolean {
        if (!this.view || !this.isMarkdownFile()) return false;
        const files = getPastedImageFiles(event.clipboardData);
        if (!files.length) return false;
        event.preventDefault();
        event.stopPropagation();
        void this.insertPastedImages(files);
        return true;
    }

    private createPastedImageSuffix(index: number, attempt: number): string {
        const random = this.ownerWindow.crypto?.randomUUID?.().replace(/-/g, '').slice(0, 8)
            || `${Date.now().toString(36)}${Math.random().toString(36).slice(2, 6)}`;
        const prefix = index > 0 || attempt > 0 ? `${index + 1}-${attempt + 1}-` : '';
        return `${prefix}${random}`;
    }

    private isFileExistsUploadError(error: unknown): boolean {
        const err = error as { status?: number; code?: string; message?: string } | null;
        return err?.status === 409 || err?.code === 'file_exists' || /already exists/i.test(err?.message || '');
    }

    private async uploadPastedImage(file: File, index: number): Promise<string> {
        const targetDir = getWorkspaceDirectoryForEditorPath(this.path);
        const extension = getPastedImageExtension(file) || 'png';
        for (let attempt = 0; attempt < 5; attempt += 1) {
            const filename = buildPastedImageFilename(this.path, file, {
                suffix: this.createPastedImageSuffix(index, attempt),
            });
            const uploadFile = new File([file], filename, { type: file.type || `image/${extension}` });
            try {
                const result = await uploadWorkspaceFile(uploadFile, targetDir, { overwrite: false });
                return typeof result?.name === 'string' && result.name ? result.name : filename;
            } catch (error) {
                if (attempt < 4 && this.isFileExistsUploadError(error)) continue;
                throw error;
            }
        }
        throw new Error('Could not choose an unused image filename');
    }

    private async insertPastedImages(files: File[]): Promise<void> {
        if (!files.length) return;
        this.updateStatusText(`Uploading pasted image${files.length === 1 ? '' : 's'}…`);
        try {
            const markdown: string[] = [];
            for (let index = 0; index < files.length; index += 1) {
                const filename = await this.uploadPastedImage(files[index], index);
                markdown.push(buildMarkdownImageText(filename));
            }
            if (!this.view || this.disposed) return;
            this.view.dispatch(this.view.state.replaceSelection(markdown.join('\n')));
            this.view.focus();
            this.updateStatusText(`Pasted image${files.length === 1 ? '' : 's'} inserted`);
        } catch (error: any) {
            if (!this.disposed) {
                this.updateStatusText(`Image paste failed: ${error?.message || 'Upload failed'}`);
            }
        }
    }

    // ── Theme ───────────────────────────────────────────────────

    private handleThemeChange(): void {
        if (!this.view || this.disposed) return;
        const isDark = getThemeMode(this.ownerDocument) === 'dark';

        this.view.dispatch({
            effects: [
                this.themeCompartment.reconfigure(editorTheme(isDark)),
            ],
        });
        this.baselineView?.dispatch({
            effects: [
                this.baselineThemeCompartment.reconfigure(editorTheme(isDark)),
            ],
        });
    }

    // ── Keyboard shortcuts ──────────────────────────────────────

    private handleGlobalKeydown(e: KeyboardEvent): void {
        // Mod+S → save
        if ((e.metaKey || e.ctrlKey) && e.key === 's') {
            e.preventDefault();
            this.handleSave();
            return;
        }

        const isAltOnly = e.altKey && !e.metaKey && !e.ctrlKey && !e.shiftKey;
        if (isAltOnly && (e.key === 'w' || e.key === 'W')) {
            e.preventDefault();
            e.stopPropagation();
            this.toggleWhitespace();
            return;
        }
        if (isAltOnly && (e.key === 'v' || e.key === 'V')) {
            e.preventDefault();
            e.stopPropagation();
            this.toggleVim();
            return;
        }
        if (isAltOnly && (e.key === 'p' || e.key === 'P')) {
            e.preventDefault();
            e.stopPropagation();
            this.toggleLivePreview();
            return;
        }
        if (isAltOnly && (e.key === 'q' || e.key === 'Q')) {
            e.preventDefault();
            e.stopPropagation();
            this.closeCb?.();
            return;
        }
        if (e.key === 'Escape' && !e.defaultPrevented && !this.dirty) {
            this.closeCb?.();
        }
    }

    // ── UI updates ──────────────────────────────────────────────

    private setLoadingUI(loading: boolean): void {
        if (loading) {
            this.bodyEl.classList.add('disabled');
            this.updateStatusText('Loading…');
        } else {
            this.bodyEl.classList.remove('disabled');
            this.updateStatusText('Ready');
        }
    }

    private setErrorUI(message: string): void {
        this.bodyEl.classList.add('disabled');
        // Insert error element before body
        let errEl = this.paneEl.querySelector('.editor-error');
        if (!errEl) {
            errEl = this.ownerDocument.createElement('div');
            errEl.className = 'editor-error';
            this.paneEl.insertBefore(errEl, this.bodyEl);
        }
        errEl.textContent = message;
    }

    private updateSaveButton(): void {
        if (!this._saveBtn) return;
        this._saveBtn.disabled = !this.dirty || this.saving;
        this._saveBtn.textContent = this.saving ? 'Saving…' : 'Save';
        this._saveBtn.title = this.dirty ? 'Save changes' : 'No changes to save';
    }

    private updateReferenceButton(): void {
        if (!this._referenceBtn) return;
        const path = normalizeEditorFileReferencePath(this.path);
        this._referenceBtn.disabled = !path;
        this._referenceBtn.title = path
            ? `Insert file reference into chat: ${path}`
            : 'No file path to reference';
        this._referenceBtn.setAttribute('aria-label', path
            ? `Insert file reference into chat: ${path}`
            : 'Insert file reference into chat');
    }

    private handleReferenceFile(): void {
        const path = normalizeEditorFileReferencePath(this.path);
        if (!path) {
            this.updateStatusText('No file path to reference');
            return;
        }
        const dispatched = dispatchEditorFileReferenceRequest(path, this.ownerWindow);
        this.updateStatusText(dispatched
            ? `Added ${path.split('/').pop() || path} to chat references`
            : 'Could not add file reference to chat');
    }

    private async refreshBranchHint(): Promise<void> {
        const token = ++this.branchRequestToken;
        const path = this.path || '';
        if (!path) {
            this.setBranchHint(null, null);
            return;
        }
        try {
            const payload = await getWorkspaceBranch(path);
            if (this.disposed || token !== this.branchRequestToken) return;
            this.setBranchHint(payload?.branch || null, payload?.repo_path || null);
        } catch {
            if (this.disposed || token !== this.branchRequestToken) return;
            this.setBranchHint(null, null);
        }
    }

    private setBranchHint(branch: string | null, repoPath: string | null): void {
        if (!this._branchHint || !this._branchLabel) return;
        const label = typeof branch === 'string' ? branch.trim() : '';
        if (!label) {
            this._branchHint.hidden = true;
            this._branchHint.removeAttribute('title');
            this._branchLabel.textContent = '';
            return;
        }
        this._branchLabel.textContent = label;
        this._branchHint.title = repoPath && repoPath !== '.'
            ? `Git branch: ${label} (${repoPath})`
            : `Git branch: ${label}`;
        this._branchHint.hidden = false;
    }

    // ── External change detection ───────────────────────────────

    private initConflictMonitor(): void {
        this.conflictMonitor?.dispose();
        if (!this.path) return;
        this.conflictMonitor = createFileConflictMonitor({
            path: this.path,
            getCurrentMtime: () => this.currentMtime,
            anchorParent: this.paneEl,
            anchorBefore: this.bodyEl,
            ownerDocument: this.ownerDocument,
            onReload: async () => {
                this.updateStatusText('Reloading…');
                try {
                    const data = await getWorkspaceFile(this.path, EDITOR_MAX_BYTES, 'edit');
                    if (this.disposed) return;
                    if (data?.error) { this.updateStatusText(`Reload failed: ${data.error}`); return; }
                    const viewState = this.captureViewState();
                    this.initialContent = data?.text || '';
                    this.initialContentLength = this.initialContent.length;
                    this.largeDocumentMode = isLargeDocumentContent(this.initialContent);
                    this.currentMtime = data?.mtime || null;
                    this.renderEditorSurface(this.initialContent, this.diffMode, viewState);
                    this.setDirty(false);
                    this.updateStatusText('Reloaded from disk');
                    this.conflictMonitor?.onSaved(this.currentMtime);
                } catch (err: any) {
                    this.updateStatusText(`Reload failed: ${err?.message || 'Unknown error'}`);
                }
            },
            onSaveCopy: async (copyPath) => {
                if (!this.view) return;
                const content = this.view.state.doc.toString();
                this.updateStatusText(`Saving copy to ${copyPath}…`);
                try {
                    await updateWorkspaceFile(copyPath, content);
                    this.updateStatusText(`Copy saved as ${copyPath}`);
                } catch (err: any) {
                    this.updateStatusText(`Save copy failed: ${err?.message || 'Unknown error'}`);
                }
            },
            onOverwrite: () => this.handleSave(),
        });
        this.conflictMonitor.start();
    }

    private updateStatusText(text: string): void {
        if (this._statusText) this._statusText.textContent = text;
    }

    private updateGutterWidth(): void {
        if (!this.view) return;
        const gutters = this.view.dom.querySelector('.cm-gutters');
        if (!gutters) return;
        const width = Math.max(32, Math.round(gutters.getBoundingClientRect().width));
        this.paneEl.style.setProperty('--cm-gutter-width', `${width}px`);
    }

    // ── PaneInstance contract ────────────────────────────────────

    getContent(): string | undefined {
        return this.view?.state.doc.toString();
    }

    isDirty(): boolean {
        return this.dirty;
    }

    getCurrentMtime(): string | null {
        return this.currentMtime;
    }

    setContent(content: string, mtime: string): void {
        if (!this.view) {
            this.mountEditor(content, mtime);
            return;
        }
        const viewState = this.captureViewState();
        this.initialContent = content;
        this.initialContentLength = content.length;
        this.largeDocumentMode = isLargeDocumentContent(content);
        this.currentMtime = mtime;
        this.renderEditorSurface(content, this.diffMode, viewState);
        this.setDirty(false);
    }

    focus(): void {
        const cm = this.view?.contentDOM;
        if (cm) cm.focus();
    }

    openSearch(query?: string): void {
        if (!this.view) return;
        openEditorSearch(this.view, query);
    }

    closeSearch(): void {
        if (!this.view) return;
        closeEditorSearch(this.view);
    }

    isSearchOpen(): boolean {
        return this.view ? isEditorSearchOpen(this.view.state) : false;
    }

    revealText(query: string): { from: number; to: number } | null {
        if (!this.view) return null;
        return revealEditorText(this.view, query);
    }

    resize(): void {
        // CodeMirror handles resize internally
        this.updateGutterWidth();
    }

    dispose(): void {
        if (this.disposed) return;
        // Flush current viewState (including content if dirty) before tearing down,
        // so the tab store has the latest unsaved content for restore on re-mount.
        // Skip for large documents to avoid excessive memory in the tab store.
        try {
            if (this.viewStateChangeCb && this.view && this.dirty && !this.largeDocumentMode) {
                const viewState = this.captureViewState();
                if (viewState) {
                    this.viewStateChangeCb({ ...viewState, content: this.view.state.doc.toString() });
                }
            }
        } catch (err) {
            console.debug('[editor] Failed to flush view state during dispose:', err);
        }
        this.disposed = true;
        this.conflictMonitor?.dispose();
        this.clearDirtyRecheckTimer();
        this.clearContentChangeTimer();
        this.unbindHostListeners();
        this.destroyEditorViews();
        this.container.innerHTML = '';
        this.dirtyChangeCb = null;
        this.saveRequestCb = null;
        this.closeCb = null;
        this.viewStateChangeCb = null;
        this.contentChangeCb = null;
    }

    onDirtyChange(cb: (dirty: boolean) => void): void {
        this.dirtyChangeCb = cb;
    }

    onSaveRequest(cb: (content: string) => void): void {
        this.saveRequestCb = cb;
    }

    onClose(cb: () => void): void {
        this.closeCb = cb;
    }

    beforeDetachFromHost(_context: PaneHostDetachContext): void {
        const viewState = this.captureViewState();
        if (viewState && this.viewStateChangeCb) {
            this.viewStateChangeCb(viewState);
        }
        this.updateStatusText('Moving pane…');
    }

    afterAttachToHost(_context: PaneHostAttachContext): void {
        this.updateLivePreviewControlState();
        this.updateWhitespaceControlState();
        this.updateGutterWidth();
        this.updateSaveButton();
        this.updateReferenceButton();
        this.updateStatusText(this.dirty ? 'Unsaved changes' : 'All changes saved');
        requestAnimationFrame(() => this.focus());
    }

    moveHost(container: HTMLElement, context: PaneHostAttachContext): boolean {
        if (this.disposed) return false;
        const transferState = normalizeEditorHostTransferState(context.transferState) || normalizeEditorHostTransferState(this.exportHostTransferState());
        this.unbindHostListeners();
        if (this.container && this.container !== container) {
            this.container.innerHTML = '';
        }
        this.initializeHostDom(container);
        this.bindHostListeners();
        if (transferState?.content !== undefined) {
            this.mountEditor(transferState.content, transferState.mtime);
            this.applyHostTransferState(transferState);
        }
        this.afterAttachToHost(context);
        void this.refreshBranchHint();
        return true;
    }

    exportHostTransferState(): Record<string, unknown> | null {
        return {
            kind: 'editor',
            path: this.path,
            content: this.getContent() ?? '',
            initialContent: this.initialContent,
            mtime: this.currentMtime,
            dirty: this.dirty,
            diffMode: this.diffMode,
            viewState: this.captureViewState(),
        };
    }

    // ── Extended PaneInstance methods ────────────────────────────

    /** Register callback for view state changes (cursor, scroll, and content when dirty). */
    onViewStateChange(cb: (state: { cursorLine: number; cursorCol: number; scrollTop: number; content?: string }) => void): void {
        this.viewStateChangeCb = cb;
    }

    /** Register callback for document content changes. Used by external previews. */
    onContentChange(cb: (content: string) => void): () => void {
        this.contentChangeCb = cb;
        const current = this.getContent();
        if (typeof current === 'string') cb(current);
        return () => {
            if (this.contentChangeCb === cb) {
                this.contentChangeCb = null;
                this.clearContentChangeTimer();
            }
        };
    }

    /** Restore view state (cursor position + scroll). */
    restoreViewState(viewState: { cursorLine?: number; cursorCol?: number; scrollTop?: number } | null): void {
        restoreEditorViewStateBestEffort(this.view, viewState, requestAnimationFrame);
    }

    /** Get the file path this instance is editing. */
    getPath(): string {
        return this.path;
    }

    /** Update the file path (after rename). */
    setPath(newPath: string): void {
        this.path = newPath;
        if (!this.isLivePreviewAvailable()) {
            void this.applyLivePreview(false);
        } else if (this.livePreviewEnabled) {
            void this.applyLivePreview(true);
        }
        this.updateLivePreviewControlState();
        this.updateWhitespaceControlState();
        this.updateReferenceButton();
        void this.refreshBranchHint();
    }

    setDiffMode(mode: 'saved' | null): void {
        const nextMode = mode === 'saved' ? 'saved' : null;
        if (this.diffMode === nextMode) return;
        const content = this.getContent() ?? this.initialContent;
        const viewState = this.captureViewState();
        this.diffMode = nextMode;
        this.renderEditorSurface(content, this.diffMode, viewState);
        this.updateLivePreviewControlState();
        this.updateWhitespaceControlState();
        this.updateGutterWidth();
        this.checkDirty(true);
    }
}

// ── Extension registration ──────────────────────────────────────

/**
 * Standalone editor pane extension. Handles all text files.
 * Creates CodeMirror directly — no Preact component intermediary.
 */
export const editorPaneExtension: WebPaneExtension = {
    id: 'editor',
    label: 'Editor',
    icon: 'edit',
    capabilities: ['edit'] as PaneCapability[],
    placement: 'tabs',

    canHandle(context: PaneContext): boolean | number {
        // Default/fallback pane for all files with a path.
        // Low priority (1) so specialized viewers can override.
        if (!context.path) return false;
        return 1;
    },

    mount(container: HTMLElement, context: PaneContext): PaneInstance {
        return new StandaloneEditorInstance(container, context);
    },
};

/** Type alias for host-side access to extended methods. */
export type { StandaloneEditorInstance as EditorPaneInstance };
