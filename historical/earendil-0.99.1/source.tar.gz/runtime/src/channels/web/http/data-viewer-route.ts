/**
 * data-viewer-route.ts — Lightweight authenticated CSV/TSV viewer route.
 *
 * Serves a same-origin HTML viewer that fetches workspace files through
 * /workspace/raw and renders an interactive table in-browser.
 */

import { registerExtensionRoute } from "./extension-routes.js";

const ROUTE_PREFIX = "/data-viewer";
const VIEWER_CSP = [
  "default-src 'self'",
  "script-src 'self' 'unsafe-inline'",
  "style-src 'self' 'unsafe-inline'",
  "img-src 'self' data: blob:",
  "connect-src 'self'",
  "frame-src 'self'",
  "frame-ancestors 'self'",
  "base-uri 'self'",
  "form-action 'self'",
].join('; ');

function generateCsvViewerPage(): string {
  return `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>CSV Viewer</title>
<style>
  * { box-sizing: border-box; }
  html, body {
    width: 100%; height: 100%; margin: 0; overflow: hidden;
    background: #fff; color: #222;
    color-scheme: light;
    font-family: system-ui, -apple-system, sans-serif; font-size: 12px;
  }
  @media (prefers-color-scheme: dark) {
    html, body { background: #111; color: #e0e0e0; color-scheme: dark; }
    th { background: #1a1a1a !important; color: #ccc; border-color: #333 !important; }
    td { border-color: #262626 !important; }
    td:first-child { background: #161616 !important; color: #777; }
    tbody tr:nth-child(even) td:not(:first-child) { background: rgba(255,255,255,0.02); }
    #toolbar { background: rgba(20,20,20,0.95); }
    #toolbar label { color: #aaa; }
    #toolbar input { background: #222; color: #e0e0e0; border-color: #444; color-scheme: dark; }
    #toolbar input::placeholder { color: #8a8a8a; }
    #toolbar .info { color: #888; }
  }
  .grid-wrap { width: 100%; height: 100%; overflow: auto; }
  table { border-collapse: separate; border-spacing: 0; min-width: 100%; width: max-content; }
  th, td {
    padding: 4px 10px; border-right: 1px solid #e5e5e5; border-bottom: 1px solid #e5e5e5;
    text-align: left; vertical-align: top; max-width: 420px; white-space: pre-wrap; word-break: break-word;
  }
  th {
    position: sticky; top: 0; z-index: 2;
    background: #f5f5f5; font-weight: 600; font-size: 11px;
  }
  td:first-child {
    position: sticky; left: 0; z-index: 1;
    background: #fafafa; color: #999; width: 48px; min-width: 48px; font-size: 11px;
  }
  thead th:first-child { z-index: 3; }
  tbody tr:nth-child(even) td:not(:first-child) { background: rgba(0,0,0,0.015); }
  .match { background: rgba(29,155,240,0.25); border-radius: 2px; }
  .empty { display: flex; width: 100%; height: 100%; align-items: center; justify-content: center; color: #888; font-size: 13px; padding: 24px; text-align: center; }

  /* Hover toolbar */
  #toolbar-trigger { position: fixed; top: 0; right: 0; width: 200px; height: 24px; z-index: 99; }
  #toolbar {
    position: fixed; top: 0; right: 0; z-index: 100;
    display: flex; align-items: center; gap: 6px; padding: 6px 10px;
    background: rgba(245,245,245,0.95); border-bottom-left-radius: 6px;
    backdrop-filter: blur(6px); -webkit-backdrop-filter: blur(6px);
    opacity: 0; transition: opacity 0.2s;
  }
  #toolbar-trigger:hover + #toolbar, #toolbar:hover { opacity: 1; }
  #toolbar label { font-size: 11px; color: #888; }
  #toolbar input {
    width: 180px; border: 1px solid #ddd; border-radius: 4px;
    background: #fff; color: #222; padding: 4px 8px; font: inherit; font-size: 12px;
  }
  #toolbar .info { font-size: 10px; color: #aaa; white-space: nowrap; }
</style>
</head>
<body>
<div id="toolbar-trigger"></div>
<div id="toolbar">
  <label>Search</label>
  <input id="search" type="search" placeholder="Filter rows…">
  <span class="info" id="info"></span>
</div>
<div id="grid" class="grid-wrap"></div>
<script>
(function () {
  'use strict';
  var params = new URLSearchParams(location.search);
  var path = params.get('path') || '';
  var gridEl = document.getElementById('grid');
  var searchEl = document.getElementById('search');
  var infoEl = document.getElementById('info');
  var allRows = [], header = [], delimiter = ',';

  function esc(v) { return String(v||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;'); }

  function detectDelimiter(text, fp) {
    if (String(fp||'').toLowerCase().endsWith('.tsv')) return '\\t';
    var lines = text.split(/\\r\\n?|\\n/).filter(function(l){return l.length>0;}).slice(0,12);
    var cands = [',',';','\\t','|'], best=',', bestS=-1;
    for (var i=0;i<cands.length;i++) {
      var d=cands[i], cs=lines.map(function(l){return l.split(d).length;}).filter(function(c){return c>1;});
      if(!cs.length)continue;
      var s=cs.length*100+Math.min.apply(Math,cs)-(Math.max.apply(Math,cs)-Math.min.apply(Math,cs));
      if(s>bestS){best=d;bestS=s;}
    }
    return best;
  }

  function parseDelimited(text, d) {
    var rows=[],row=[],cell='',inQ=false;
    for(var i=0;i<text.length;i++){
      var ch=text[i];
      if(inQ){if(ch==='"'){if(text[i+1]==='"'){cell+='"';i++;}else inQ=false;}else cell+=ch;continue;}
      if(ch==='"'){inQ=true;continue;}
      if(ch===d){row.push(cell);cell='';continue;}
      if(ch==='\\n'){row.push(cell);rows.push(row);row=[];cell='';continue;}
      if(ch==='\\r')continue;
      cell+=ch;
    }
    if(cell.length||row.length){row.push(cell);rows.push(row);}
    return rows;
  }

  function visibleRows() {
    var q=String(searchEl.value||'').trim().toLowerCase();
    if(!q)return allRows;
    return allRows.filter(function(r){for(var i=0;i<r.length;i++)if(String(r[i]||'').toLowerCase().indexOf(q)>=0)return true;return false;});
  }

  function hl(text,q) {
    var raw=String(text||''); if(!q)return esc(raw);
    var idx=raw.toLowerCase().indexOf(q.toLowerCase());
    if(idx<0)return esc(raw);
    return esc(raw.slice(0,idx))+'<span class="match">'+esc(raw.slice(idx,idx+q.length))+'</span>'+esc(raw.slice(idx+q.length));
  }

  function render() {
    var rows=visibleRows(), q=String(searchEl.value||'').trim();
    if(!header.length){gridEl.innerHTML='<div class="empty">No data.</div>';return;}
    var h=['<table><thead><tr><th>#</th>'];
    for(var c=0;c<header.length;c++)h.push('<th>'+esc(header[c])+'</th>');
    h.push('</tr></thead><tbody>');
    for(var r=0;r<rows.length;r++){
      h.push('<tr><td>'+(r+1)+'</td>');
      for(var cc=0;cc<header.length;cc++)h.push('<td>'+hl(rows[r][cc]==null?'':rows[r][cc],q)+'</td>');
      h.push('</tr>');
    }
    h.push('</tbody></table>');
    gridEl.innerHTML=h.join('');
    infoEl.textContent=rows.length+' rows × '+header.length+' cols'+(q?' (filtered)':'');
  }

  searchEl.addEventListener('input', render);

  if(!path){gridEl.innerHTML='<div class="empty">Missing <code>?path=...</code></div>';return;}

  var fileName = path.split('/').pop() || 'table.csv';
  document.title = fileName + ' · CSV Viewer';

  fetch('/workspace/raw?path='+encodeURIComponent(path))
    .then(function(res){if(!res.ok)throw new Error('HTTP '+res.status);return res.text();})
    .then(function(text){
      delimiter=detectDelimiter(text,path);
      var rows=parseDelimited(text,delimiter).filter(function(r){return r.some(function(c){return String(c||'').length>0;});});
      if(!rows.length){header=[];allRows=[];render();return;}
      var maxC=rows.reduce(function(m,r){return Math.max(m,r.length);},0);
      header=rows[0].slice();
      while(header.length<maxC)header.push('Col '+(header.length+1));
      for(var i=0;i<header.length;i++)if(!String(header[i]||'').trim())header[i]='Col '+(i+1);
      allRows=rows.slice(1).map(function(r){var n=r.slice();while(n.length<maxC)n.push('');return n;});
      render();
    })
    .catch(function(err){gridEl.innerHTML='<div class="empty">Failed to load: '+esc(err.message)+'</div>';});
})();
</script>
</body>
</html>`;
}

function handleCsvViewerRoute(req: Request, pathname: string): Response | null {
  if (req.method !== "GET" && req.method !== "HEAD") {
    return new Response("Method Not Allowed", { status: 405 });
  }

  const relative = pathname.replace(/^\/data-viewer\/?/, "");
  if (relative && !relative.startsWith("?")) {
    return new Response("Not Found", { status: 404 });
  }

  const headers = {
    "Content-Type": "text/html; charset=utf-8",
    "Cache-Control": "no-cache",
    "X-Frame-Options": "SAMEORIGIN",
    "Content-Security-Policy": VIEWER_CSP,
  };

  if (req.method === "HEAD") {
    return new Response(null, { status: 200, headers });
  }

  return new Response(generateCsvViewerPage(), { status: 200, headers });
}

registerExtensionRoute(ROUTE_PREFIX, handleCsvViewerRoute, import.meta.dir);
